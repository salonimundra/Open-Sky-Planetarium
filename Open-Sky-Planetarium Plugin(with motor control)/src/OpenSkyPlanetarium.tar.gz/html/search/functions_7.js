var searchData=
[
  ['move',['move',['../class_o_s_p_main_dialog.html#a926b0132bfacc026a35847ec0c1f8b0a',1,'OSPMainDialog::move()'],['../class_laser_dev.html#ae66064fa79825cfdc8fb604db0d462af',1,'LaserDev::move()']]],
  ['movx',['movx',['../class_laser_dev.html#a2e229a59571fa9dcd93ebc6a23ecb3c1',1,'LaserDev']]],
  ['movy',['movy',['../class_laser_dev.html#a6d9a60d963031c9104200014a380b55e',1,'LaserDev']]]
];
