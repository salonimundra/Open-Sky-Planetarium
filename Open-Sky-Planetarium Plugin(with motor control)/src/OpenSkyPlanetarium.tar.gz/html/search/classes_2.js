var searchData=
[
  ['openskyplanetarium',['OpenSkyPlanetarium',['../class_open_sky_planetarium.html',1,'']]],
  ['openskyplanetariumplugininterface',['OpenSkyPlanetariumPluginInterface',['../class_open_sky_planetarium_plugin_interface.html',1,'']]],
  ['ospmaindialog',['OSPMainDialog',['../class_o_s_p_main_dialog.html',1,'']]]
];
