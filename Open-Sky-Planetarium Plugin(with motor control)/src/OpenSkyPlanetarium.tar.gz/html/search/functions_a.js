var searchData=
[
  ['response',['response',['../class_serial_com.html#a9e83e2b67a01ee9504719c4b11375635',1,'SerialCom']]],
  ['retranslate',['retranslate',['../class_o_s_p_main_dialog.html#a47ea6fd9f98519cc31e72f5de34a9306',1,'OSPMainDialog']]],
  ['rightpressed',['rightPressed',['../class_o_s_p_main_dialog.html#add7447fb9aa1e92241e9dafb24be9eee',1,'OSPMainDialog']]],
  ['run',['run',['../class_serial_com.html#a842c52f3e42ee3cc4b7c1ebaff83c560',1,'SerialCom']]]
];
