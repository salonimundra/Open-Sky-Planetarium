var searchData=
[
  ['update',['update',['../class_open_sky_planetarium.html#a71cdbeed316e46fc4e84bf76fadabe62',1,'OpenSkyPlanetarium']]],
  ['uppressed',['upPressed',['../class_o_s_p_main_dialog.html#a1d029fbbacb738ec5f96387afc4a148c',1,'OSPMainDialog']]]
];
