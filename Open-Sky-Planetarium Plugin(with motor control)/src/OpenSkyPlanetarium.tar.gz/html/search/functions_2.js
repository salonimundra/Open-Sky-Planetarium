var searchData=
[
  ['debug_5freceived',['debug_received',['../class_o_s_p_main_dialog.html#a3e1eb9ec4e4b720c5710b6dd919cff2a',1,'OSPMainDialog']]],
  ['debug_5fsend',['debug_send',['../class_laser_dev.html#a5f64ad8bfee8c6a870d5b6cf8c22ad85',1,'LaserDev']]],
  ['deinit',['deinit',['../class_open_sky_planetarium.html#a163cb7c2ecf113d829f0eec67d4e853d',1,'OpenSkyPlanetarium']]],
  ['downpressed',['downPressed',['../class_o_s_p_main_dialog.html#a2d9c9e8eadf0566c6a62b56c256d3036',1,'OSPMainDialog']]]
];
