var searchData=
[
  ['openscript',['openScript',['../class_o_s_p_main_dialog.html#a81e34e4b686fc8a240b8b60fce8db716',1,'OSPMainDialog']]],
  ['openskyplanetarium',['OpenSkyPlanetarium',['../class_open_sky_planetarium.html#a5f8863f2909ea7c84722d8f1d1410aac',1,'OpenSkyPlanetarium']]],
  ['ospmaindialog',['OSPMainDialog',['../class_o_s_p_main_dialog.html#a10db9ace40cfdd733c99d1fa9564bd2a',1,'OSPMainDialog']]]
];
