var class_calibrate =
[
    [ "Calibrate", "class_calibrate.html#af7fd8ee2339ee66f6f8e4d9953025796", null ],
    [ "autoRef_3", "class_calibrate.html#a21d7622c2356e44897dbfed2f9d9d1d9", null ],
    [ "getECoords", "class_calibrate.html#ab7e978f3fff297d01addb3decdc2ae15", null ],
    [ "getHCoords", "class_calibrate.html#a611a5a3f616c57325493a4552aadab2c", null ],
    [ "isConfigured", "class_calibrate.html#a55a935c9efccedcc965cc9de4da5d3be", null ],
    [ "setRef_1", "class_calibrate.html#accdf063b97064170400a396d50ca364a", null ],
    [ "setRef_2", "class_calibrate.html#a0de0f875a4426d90c7c67cf9aa7a117c", null ],
    [ "setRef_3", "class_calibrate.html#af3f3b8373b846d5e19006feef1a29c96", null ],
    [ "setTime", "class_calibrate.html#aa995deb89e9bf1afe158a9863feeb9b5", null ]
];