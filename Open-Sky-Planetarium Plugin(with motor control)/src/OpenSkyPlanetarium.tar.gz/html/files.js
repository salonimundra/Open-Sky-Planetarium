var files =
[
    [ "gui", "dir_11bc0974ce736ce9a6fadebbeb7a8314.html", "dir_11bc0974ce736ce9a6fadebbeb7a8314" ],
    [ "Calibrate.cpp", "_calibrate_8cpp.html", null ],
    [ "Calibrate.hpp", "_calibrate_8hpp.html", [
      [ "Calibrate", "class_calibrate.html", "class_calibrate" ]
    ] ],
    [ "LaserDev.cpp", "_laser_dev_8cpp.html", null ],
    [ "LaserDev.hpp", "_laser_dev_8hpp.html", [
      [ "LaserDev", "class_laser_dev.html", "class_laser_dev" ]
    ] ],
    [ "OpenSkyPlanetarium.cpp", "_open_sky_planetarium_8cpp.html", null ],
    [ "OpenSkyPlanetarium.hpp", "_open_sky_planetarium_8hpp.html", [
      [ "OpenSkyPlanetarium", "class_open_sky_planetarium.html", "class_open_sky_planetarium" ],
      [ "OpenSkyPlanetariumPluginInterface", "class_open_sky_planetarium_plugin_interface.html", "class_open_sky_planetarium_plugin_interface" ]
    ] ],
    [ "SerialCom.cpp", "_serial_com_8cpp.html", null ],
    [ "SerialCom.hpp", "_serial_com_8hpp.html", [
      [ "SerialCom", "class_serial_com.html", "class_serial_com" ]
    ] ]
];