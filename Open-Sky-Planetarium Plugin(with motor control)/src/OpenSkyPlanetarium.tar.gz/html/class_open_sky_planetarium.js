var class_open_sky_planetarium =
[
    [ "OpenSkyPlanetarium", "class_open_sky_planetarium.html#a5f8863f2909ea7c84722d8f1d1410aac", null ],
    [ "~OpenSkyPlanetarium", "class_open_sky_planetarium.html#a4df59ddbb670aef575f97bbcef1267c8", null ],
    [ "configureGui", "class_open_sky_planetarium.html#a36c4660bffbd77013a7f1007f9cace16", null ],
    [ "deinit", "class_open_sky_planetarium.html#a163cb7c2ecf113d829f0eec67d4e853d", null ],
    [ "getCallOrder", "class_open_sky_planetarium.html#a7880a253b939c93cc93bb10bbc04fd96", null ],
    [ "init", "class_open_sky_planetarium.html#ad3219ba7597f58f41eb2f175b5b3ca43", null ],
    [ "update", "class_open_sky_planetarium.html#a71cdbeed316e46fc4e84bf76fadabe62", null ]
];