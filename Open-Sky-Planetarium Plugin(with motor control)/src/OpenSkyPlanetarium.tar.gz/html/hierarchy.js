var hierarchy =
[
    [ "Calibrate", "class_calibrate.html", null ],
    [ "QObject", null, [
      [ "LaserDev", "class_laser_dev.html", null ],
      [ "OpenSkyPlanetariumPluginInterface", "class_open_sky_planetarium_plugin_interface.html", null ]
    ] ],
    [ "QThread", null, [
      [ "SerialCom", "class_serial_com.html", null ]
    ] ],
    [ "StelDialog", null, [
      [ "OSPMainDialog", "class_o_s_p_main_dialog.html", null ]
    ] ],
    [ "StelModule", null, [
      [ "OpenSkyPlanetarium", "class_open_sky_planetarium.html", null ]
    ] ],
    [ "StelPluginInterface", null, [
      [ "OpenSkyPlanetariumPluginInterface", "class_open_sky_planetarium_plugin_interface.html", null ]
    ] ]
];