var annotated =
[
    [ "Calibrate", "class_calibrate.html", "class_calibrate" ],
    [ "LaserDev", "class_laser_dev.html", "class_laser_dev" ],
    [ "OpenSkyPlanetarium", "class_open_sky_planetarium.html", "class_open_sky_planetarium" ],
    [ "OpenSkyPlanetariumPluginInterface", "class_open_sky_planetarium_plugin_interface.html", "class_open_sky_planetarium_plugin_interface" ],
    [ "OSPMainDialog", "class_o_s_p_main_dialog.html", "class_o_s_p_main_dialog" ],
    [ "SerialCom", "class_serial_com.html", "class_serial_com" ]
];