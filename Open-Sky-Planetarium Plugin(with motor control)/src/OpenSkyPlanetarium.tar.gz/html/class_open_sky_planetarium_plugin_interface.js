var class_open_sky_planetarium_plugin_interface =
[
    [ "getPluginInfo", "class_open_sky_planetarium_plugin_interface.html#afb592a06233f9bea5e6149e7bfd364aa", null ],
    [ "getStelModule", "class_open_sky_planetarium_plugin_interface.html#af89d90ab4d905c0818ca6bdc966ed6ee", null ]
];