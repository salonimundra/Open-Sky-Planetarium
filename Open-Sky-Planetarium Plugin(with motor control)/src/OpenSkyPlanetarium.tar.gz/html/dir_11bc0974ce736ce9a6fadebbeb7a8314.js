var dir_11bc0974ce736ce9a6fadebbeb7a8314 =
[
    [ "OSPMainDialog.cpp", "_o_s_p_main_dialog_8cpp.html", null ],
    [ "OSPMainDialog.hpp", "_o_s_p_main_dialog_8hpp.html", [
      [ "OSPMainDialog", "class_o_s_p_main_dialog.html", "class_o_s_p_main_dialog" ]
    ] ]
];